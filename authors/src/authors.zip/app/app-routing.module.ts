import { AddAuthorComponent } from './add-author/add-author.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowAuthorsComponent } from './show-authors/show-authors.component';
import { EditAuthorComponent } from './edit-author/edit-author.component';

const routes: Routes = [
  { path: 'addauthor', component: AddAuthorComponent },
  { path: 'editauthor/:id', component: EditAuthorComponent },
  { path: 'showauthor', component: ShowAuthorsComponent },
  { path: '', pathMatch: 'full', redirectTo: '/showauthor' },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
